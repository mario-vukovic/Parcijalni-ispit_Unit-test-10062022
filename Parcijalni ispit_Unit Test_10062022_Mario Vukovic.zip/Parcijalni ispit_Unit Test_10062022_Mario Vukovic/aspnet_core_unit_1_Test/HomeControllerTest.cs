﻿using aspnet_core_unit_1.Controllers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace aspnet_core_unit_1_Test
{
    public class HomeControllerTest
    {
        private readonly HomeController homeController;

        public HomeControllerTest()
        {
            this.homeController = new HomeController();
        }

        [Fact]
        public void CheckCountValue_Input500_ThrowsException()
        {
            Assert.Throws<Exception>(() => homeController.CheckCountValue(500));
        }

        [Fact]
        public void CheckCountValue_Input2_ReturnsView()
        {
            ViewResult view = homeController.CheckCountValue(2) as ViewResult;
            Assert.NotNull(view);

            
        }
    }
}
